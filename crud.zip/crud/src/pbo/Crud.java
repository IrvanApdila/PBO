/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Crud {
    private static Connection MysQLConfig;
    
    public static Connection configDB()throws SQLException{
        try{
            String url = "jdbc:mysql://localhost/hotel";
            String user = "root";
            String pass = "";                    
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            MysQLConfig = DriverManager.getConnection(url,user,pass);
        
        }catch(SQLException e){
            System.out.println("koneksi gagal"+ e.getMessage());
        }
        return MysQLConfig; 
}
}
